#!/bin/bash
# Mostra todos os parâmetros recebidos, contando suas posições.

# Começa a contagem pelo parâmetro 1.
contador=1

# Continua enquanto existir algum parâmetro.
while [ "$#" -gt 0 ]; do
    # Mostra a posição e o valor do parâmetro atual.
    echo "Parâmetro $contador: $1"

    # Passa para o próximo parâmetro.
    shift

    # Aumenta a contagem.
    contador=$((contador + 1))
done
