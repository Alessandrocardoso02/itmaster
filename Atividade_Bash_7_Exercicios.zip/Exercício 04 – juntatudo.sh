#!/bin/bash
# Junta todos os parâmetros recebidos em uma única palavra.

# Mostra todos os parâmetros sem os espaços entre eles.
echo "$*" | tr -d ' '
