#!/bin/bash
# Recebe dois números e compara os valores.

# Guarda o primeiro parâmetro.
num1=$1

# Guarda o segundo parâmetro.
num2=$2

# Verifica se o primeiro número é menor que o segundo.
if [ "$num1" -lt "$num2" ]; then
    echo "$num1 é menor que $num2"

# Verifica se o primeiro número é maior que o segundo.
elif [ "$num1" -gt "$num2" ]; then
    echo "$num1 é maior que $num2"

# Caso não seja menor nem maior, os números são iguais.
else
    echo "$num1 é igual a $num2"
fi
