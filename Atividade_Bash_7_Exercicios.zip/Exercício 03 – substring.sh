#!/bin/bash
# Verifica se a primeira palavra está contida dentro da segunda.

# Guarda a primeira palavra.
palavra1=$1

# Guarda a segunda palavra.
palavra2=$2

# Procura a primeira palavra dentro da segunda.
if echo "$palavra2" | grep -q "$palavra1"; then
    # Mostra a mensagem somente quando encontrar.
    echo "$palavra1 está contida em $palavra2"
fi
