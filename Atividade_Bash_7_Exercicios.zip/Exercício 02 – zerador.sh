#!/bin/bash
# Recebe um número e diminui o valor até chegar a zero.

# Guarda o número recebido.
numero=$1

# Repete enquanto o número for maior ou igual a zero.
while [ "$numero" -ge 0 ]; do
    # Mostra o número na mesma linha.
    echo -n "$numero "

    # Diminui o número em 1.
    numero=$((numero - 1))
done

# Pula para a próxima linha.
echo
