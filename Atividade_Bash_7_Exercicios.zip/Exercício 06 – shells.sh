#!/bin/bash
# Mostra os shells usados pelos usuários sem repetir os valores.

# Pega o último campo de cada linha do arquivo /etc/passwd.
cut -d: -f7 /etc/passwd | sort | uniq
