#!/bin/bash
# Mostra o usuário e o nome completo dos usuários do sistema.

# Lê o arquivo /etc/passwd e pega os campos 1 e 5 separados por TAB.
cut -d: -f1,5 /etc/passwd | tr ':' '\t'
